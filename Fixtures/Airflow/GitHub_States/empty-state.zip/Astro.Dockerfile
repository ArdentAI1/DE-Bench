ARG BASE_IMAGE=quay.io/astronomer/astro-runtime:13.1.0-slim
FROM ${BASE_IMAGE}

USER root

# Copy requirements.txt into the container
COPY /Requirements/requirements.txt /usr/local/airflow/requirements.txt

# Switch back to airflow user for pip install
USER astro

# Install dependencies from requirements.txt
# if pandas is in the requirements.txt, install GCC first
RUN if grep -q "pandas" requirements.txt; then \
        apt-get update && \
        apt-get install -y gcc && \
        apt-get clean && \
        rm -rf /var/lib/apt/lists/*; \
    fi; \
    pip install --no-cache-dir -r requirements.txt
