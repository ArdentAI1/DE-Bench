from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash_operator import BashOperator

# Default arguments
default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "start_date": datetime(2024, 1, 1),
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}

# Define the DAG
dag = DAG(
    "hello_world_dag",
    default_args=default_args,
    description="A simple Hello World DAG",
    schedule_interval="@daily",  # Runs daily at midnight
    catchup=False,  # Prevents backfilling
    tags=["example", "hello_world"],
)

# Create the tasks
print_hello = BashOperator(
    task_id="print_hello", bash_command='echo "Hello World"', dag=dag
)

fail_task = BashOperator(
    task_id="intentional_failure", bash_command="cat /nonexistent/file.txt", dag=dag
)

# Task dependencies - hello succeeds, then failure happens
print_hello >> fail_task
