#!/bin/bash
set -e

echo "Initializing Airflow database..."

# Initialize the database and run migrations
airflow db migrate

# Initialize Flask AppBuilder roles and permissions using Python
echo "Creating Flask AppBuilder roles..."
python3 << 'PYEOF'
import sys
from airflow.www.app import create_app
from airflow import settings

try:
    # Create the Flask app which initializes the appbuilder
    app = create_app()
    with app.app_context():
        # Access the security manager to create roles
        appbuilder = app.appbuilder

        # This will create all the default roles including Admin
        print("Initializing security manager...")
        appbuilder.sm.sync_roles()
        print("Roles created successfully!")

except Exception as e:
    print(f"Error creating roles: {e}", file=sys.stderr)
    sys.exit(1)
PYEOF

# Set admin password from environment variable or use default
ADMIN_PASSWORD="${AIRFLOW_PASSWORD:-admin}"

echo "Creating admin user..."
# Create admin user (this will skip if user already exists)
airflow users create \
    --username admin \
    --firstname Admin \
    --lastname User \
    --role Admin \
    --email admin@example.com \
    --password "$ADMIN_PASSWORD" 2>&1 | grep -v "already exist" || true

echo ""
echo "=========================================="
echo "Airflow Admin Credentials:"
echo "Username: admin"
echo "Password: $ADMIN_PASSWORD"
echo "=========================================="
echo ""

echo "=========================================="
echo "Starting airflow in standalone mode..."
echo "=========================================="
airflow standalone
